/**
 * 
 */
package jeu;

/**
 * @author Steven ISAMBERT-PAYET
 * @version 0.1
 *
 */
public class InterfaceAvecC {
	//en attente de la version C
}
