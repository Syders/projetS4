/**
 * 
 */
package jeu;

/**
 * @author Steven ISAMBERT-PAYET
 * @version 0.1
 * 
 */
public class Plateau {
	private int taille=11;

	public Plateau(int taille) {
		//super();
		this.taille = taille;
	}
	/**
	 * @author Steven ISAMBERT-PAYET
	 * @category Plateau\Affichage
	 * @param taille
	 * @param tab
	 */
	public void affichageTableau(int taille, int tab[]){
		for(int i=0;i<taille;i++){
			System.out.println("W ");
		}
		System.out.println("W/B\n");
		for(int j=0;j<taille;j++){
			for(int i=0;i<taille+1;i++){
				if(i==0)System.out.println("B");
				System.out.println(tab[j+i]);
			}
			System.out.println("B\n");
		}
		System.out.println("B/W ");
		for(int i=0;i<taille-1;i++){
			System.out.println("W ");
		}
		System.out.println("W\n * pour les noirs (B) et o pour les blancs (W) \n");
	}
}
