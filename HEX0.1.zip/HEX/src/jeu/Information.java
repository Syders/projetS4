/**
 * 
 */
package jeu;

/**
 * @author Steven ISAMBERT-PAYET
 * @version 0.1
 *
 */
public class Information {
	private int noJoueur;
	private int noTour;
	private String dernierCoupJoue;
	private int noCoup;
	private char pionDuJoueur;
	public Information(int noJoueur, char pionDuJoueur) {
		//super();
		this.noJoueur = noJoueur;
		this.noTour = 1;
		this.dernierCoupJoue = " ";
		this.noCoup = 0;
		this.pionDuJoueur = pionDuJoueur;
	}
	
	public int getNoJoueur() {
		return noJoueur;
	}

	public void affichageInformation(){
		System.out.println(" Joueur n�" + noJoueur + "\n Tour n�" + noTour + "\n Dernier Coup Jou�: " + dernierCoupJoue + "\n Coup du Joueur n�" + noCoup + "\n Pion du Joueur: " + pionDuJoueur + "\n" );
	}
	
	private int changementNoTour (int noTour){
		noCoup++;
		return noTour+2;
	}
	
	public void menuJeu(){
		System.out.println("Joueur n�" + noJoueur + "votre action.\n");
	}
	
}
