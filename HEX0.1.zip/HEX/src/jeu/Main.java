/**
 * 
 */
package jeu;

/**
 * @author Steven ISAMBERT-PAYET
 * @version 0.1
 *
 */
public class Main {
	
	public static void menuPrincipal(){
		System.out.println("HEX Version 0.1 \n\nVoulez-vous commencer une partie?");
	}
	
	public static void choixDesPions(int noJoueur){
		System.out.println("Joueur n�" + noJoueur + "choisissez votre pion.\n");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			menuPrincipal();
			//inserer un choix
			
			choixDesPions(1);
			//pion n�2 sera donc l'autre
			
			//mettre initialisation des informations avec les pions
			
			
			//jeu � mettre en place avec initialisation du plateau
			
	}

}
